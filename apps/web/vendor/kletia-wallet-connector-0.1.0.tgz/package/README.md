# @kletia-wallet/connector

Kletia Wallet (the ESP32 cold wallet in this repository) for web apps:

- **EVM:** a wagmi connector and a RainbowKit wallet entry ("Kletia Wallet" in the connect modal).
- **Solana:** a Wallet Standard wallet (`standard:connect`, `solana:signTransaction`).

The browser reaches the device over **Web Bluetooth**, inside the KSC1 end-to-end encrypted channel
(see `docs/guvenli-kanal.md`). Every transaction is decoded and shown on the device's screen, and is
signed only after the user presses the approve button. Private keys never leave the device.

## Use

```ts
import { connectorsForWallets } from "@rainbow-me/rainbowkit";
import { injectedWallet } from "@rainbow-me/rainbowkit/wallets";
import { kletiaWallet, registerKletiaSolanaWallet } from "@kletia-wallet/connector";

const connectors = connectorsForWallets(
  [{ groupName: "Wallets", wallets: [injectedWallet, kletiaWallet] }],
  { appName: "Kletia", projectId: "" },
);

registerKletiaSolanaWallet(); // once, at startup
```

Without RainbowKit, use `kletiaWalletConnector()` as a wagmi connector. For another account
index, use `kletiaWalletWith({ account: 1 })`.

## What happens on connect

1. The browser's Bluetooth chooser lists "Kletia Vault"; the user picks the device.
2. The first time only, the screen and the device both show a 6-digit code. If the codes match,
   the user approves on the device, and the device remembers this browser (up to 4 phones/browsers).
3. If the device is locked, the overlay asks the user to enter the PIN on the device.
4. The EVM address (`m/44'/60'/0'/0/i`) and the Solana address (`m/44'/501'/i'/0'`) are read.

## Supported requests

| Request | Behaviour |
| --- | --- |
| `eth_requestAccounts`, `eth_accounts`, `eth_chainId` | Answered from the session. |
| `wallet_switchEthereumChain` | Any chain in the host app's wagmi config. |
| `eth_sendTransaction` | Built (nonce, gas, EIP-1559 fees from the host app's RPC), approved and signed on the device, then broadcast. |
| `personal_sign` | Shown on the device as text (or flagged as a binary message), then signed. |
| `eth_signTypedData_*` | Not supported yet (error 4200). |
| Solana `signTransaction` | Approved and signed on the device; the host app sends it. |
| Other read methods | Passed through to the host app's RPC. |

A rejection on the device returns the standard EIP-1193 code 4001 ("user rejected").

## Requirements

- Chrome, Edge or Opera on desktop or Android (Web Bluetooth). Safari and iOS have no Web Bluetooth.
- HTTPS (or localhost).
- Kletia Vault firmware 0.2.0 or later.

## Build

```sh
npm run build -w connector   # dist/index.js + dist/index.d.ts
npm pack -w connector        # kletia-wallet-connector-<version>.tgz
```
